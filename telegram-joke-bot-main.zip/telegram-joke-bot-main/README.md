# telegram-joke-bot
Telegram Bot written on Java 17 and Spring Boot 3
